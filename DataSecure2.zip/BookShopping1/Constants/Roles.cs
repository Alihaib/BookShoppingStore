﻿namespace BookShopping1.Constants
{
   public enum Roles
    {
        User=1,
        Admin
    }
}
