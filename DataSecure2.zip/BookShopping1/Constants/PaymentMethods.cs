﻿namespace BookShopping1.Constants;
 public enum PaymentMethods
{
    COD=1,
    Online

}
