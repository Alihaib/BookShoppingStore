﻿global using BookShopping1.Data;
global using BookShopping1.Models;
global using BookShopping1.Models.DTOs;
global using BookShopping1.Repositories;
global using BookShopping1.Constants;